export interface JSONField {
  id: string;
  type: 'text' | 'email' | 'password' | 'number' | 'tel' | 'textarea' | 'select' | 'checkbox' | 'radio' | 'date' | 'file';
  label: string;
  placeholder?: string;
  required?: boolean;
  validation?: {
    minLength?: number;
    maxLength?: number;
    pattern?: string;
    min?: number;
    max?: number;
  };
  options?: string[];
  description?: string;
}

export interface JSONSection {
  id: string;
  title: string;
  description?: string;
  fields: JSONField[];
}

export interface JSONPageStructure {
  id: string;
  title: string;
  description?: string;
  type: 'form' | 'dashboard' | 'landing' | 'admin';
  sections: JSONSection[];
  actions?: {
    submit?: {
      label: string;
      endpoint?: string;
      method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
    };
    cancel?: {
      label: string;
      action: string;
    };
  };
  styling?: {
    theme: 'light' | 'dark';
    layout: 'single-column' | 'two-column' | 'grid';
  };
}

export interface TrainingExample {
  id: string;
  description: string;
  jsonStructure: JSONPageStructure;
  feedback?: {
    rating: number;
    comments: string;
  };
  timestamp: string;
}

export interface GenerationResult {
  success: boolean;
  structure?: JSONPageStructure;
  confidence: number;
  processingTime: number;
  suggestions?: string[];
  error?: string;
}