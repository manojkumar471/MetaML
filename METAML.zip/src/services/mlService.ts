import { JSONPageStructure, JSONField, JSONSection, GenerationResult } from '../types';

class MLService {
  private trainingData: Array<{ description: string; structure: JSONPageStructure }> = [];

  constructor() {
    this.initializeTrainingData();
  }

  private initializeTrainingData() {
    // Sample training data to simulate a trained model
    this.trainingData = [
      {
        description: "registration form with name email and password",
        structure: {
          id: "registration-form",
          title: "User Registration",
          type: "form",
          sections: [
            {
              id: "personal-info",
              title: "Personal Information",
              fields: [
                {
                  id: "name",
                  type: "text",
                  label: "Full Name",
                  placeholder: "Enter your full name",
                  required: true
                },
                {
                  id: "email",
                  type: "email",
                  label: "Email Address",
                  placeholder: "Enter your email",
                  required: true
                },
                {
                  id: "password",
                  type: "password",
                  label: "Password",
                  placeholder: "Create a password",
                  required: true,
                  validation: { minLength: 8 }
                }
              ]
            }
          ],
          actions: {
            submit: {
              label: "Register",
              endpoint: "/api/register",
              method: "POST"
            }
          }
        }
      }
    ];
  }

  private extractKeywords(description: string): string[] {
    const keywords = description.toLowerCase().match(/\b\w+\b/g) || [];
    return [...new Set(keywords)];
  }

  private inferFieldType(fieldName: string): JSONField['type'] {
    const fieldMappings: Record<string, JSONField['type']> = {
      'email': 'email',
      'password': 'password',
      'phone': 'tel',
      'telephone': 'tel',
      'age': 'number',
      'quantity': 'number',
      'price': 'number',
      'date': 'date',
      'birthday': 'date',
      'message': 'textarea',
      'comment': 'textarea',
      'description': 'textarea',
      'bio': 'textarea',
      'file': 'file',
      'attachment': 'file',
      'country': 'select',
      'state': 'select',
      'gender': 'radio',
      'terms': 'checkbox',
      'newsletter': 'checkbox'
    };

    const lowerFieldName = fieldName.toLowerCase();
    
    for (const [key, type] of Object.entries(fieldMappings)) {
      if (lowerFieldName.includes(key)) {
        return type;
      }
    }
    
    return 'text';
  }

  private generateFieldFromKeyword(keyword: string): JSONField {
    const fieldType = this.inferFieldType(keyword);
    const fieldId = keyword.toLowerCase().replace(/\s+/g, '-');
    
    const field: JSONField = {
      id: fieldId,
      type: fieldType,
      label: keyword.charAt(0).toUpperCase() + keyword.slice(1),
      placeholder: `Enter your ${keyword.toLowerCase()}`,
      required: ['name', 'email', 'password'].includes(keyword.toLowerCase())
    };

    // Add validation rules based on field type
    if (fieldType === 'password') {
      field.validation = { minLength: 8 };
    } else if (fieldType === 'email') {
      field.validation = { pattern: '^[^@]+@[^@]+\\.[^@]+$' };
    } else if (fieldType === 'tel') {
      field.validation = { pattern: '^[+]?[0-9\\s-()]+$' };
    }

    // Add options for select and radio fields
    if (fieldType === 'select') {
      if (keyword.toLowerCase().includes('country')) {
        field.options = ['United States', 'Canada', 'United Kingdom', 'Australia', 'Germany', 'France'];
      } else if (keyword.toLowerCase().includes('state')) {
        field.options = ['California', 'New York', 'Texas', 'Florida', 'Illinois'];
      } else {
        field.options = ['Option 1', 'Option 2', 'Option 3'];
      }
    } else if (fieldType === 'radio') {
      if (keyword.toLowerCase().includes('gender')) {
        field.options = ['Male', 'Female', 'Other', 'Prefer not to say'];
      } else {
        field.options = ['Yes', 'No'];
      }
    }

    return field;
  }

  private determinePageType(description: string): JSONPageStructure['type'] {
    const lowerDesc = description.toLowerCase();
    
    if (lowerDesc.includes('dashboard') || lowerDesc.includes('admin') || lowerDesc.includes('analytics')) {
      return 'dashboard';
    } else if (lowerDesc.includes('landing') || lowerDesc.includes('homepage') || lowerDesc.includes('welcome')) {
      return 'landing';
    } else if (lowerDesc.includes('admin') || lowerDesc.includes('management')) {
      return 'admin';
    }
    
    return 'form';
  }

  private generateTitle(description: string): string {
    const lowerDesc = description.toLowerCase();
    
    if (lowerDesc.includes('registration') || lowerDesc.includes('register') || lowerDesc.includes('signup')) {
      return 'Registration Form';
    } else if (lowerDesc.includes('login') || lowerDesc.includes('signin')) {
      return 'Login Form';
    } else if (lowerDesc.includes('contact')) {
      return 'Contact Form';
    } else if (lowerDesc.includes('feedback')) {
      return 'Feedback Form';
    } else if (lowerDesc.includes('survey')) {
      return 'Survey Form';
    } else if (lowerDesc.includes('application')) {
      return 'Application Form';
    }
    
    return 'Form';
  }

  public async generateStructure(description: string): Promise<GenerationResult> {
    const startTime = Date.now();
    
    try {
      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
      
      const keywords = this.extractKeywords(description);
      const pageType = this.determinePageType(description);
      const title = this.generateTitle(description);
      
      // Filter keywords to get likely field names
      const fieldKeywords = keywords.filter(keyword => 
        !['form', 'page', 'with', 'and', 'for', 'a', 'an', 'the', 'create', 'make', 'build'].includes(keyword)
      );
      
      const fields: JSONField[] = fieldKeywords.map(keyword => 
        this.generateFieldFromKeyword(keyword)
      );
      
      // Group fields into logical sections
      const sections: JSONSection[] = [
        {
          id: 'main-section',
          title: pageType === 'form' ? 'Information' : 'Details',
          fields: fields
        }
      ];
      
      const structure: JSONPageStructure = {
        id: `generated-${Date.now()}`,
        title,
        description: `Generated from: "${description}"`,
        type: pageType,
        sections,
        actions: pageType === 'form' ? {
          submit: {
            label: 'Submit',
            endpoint: '/api/submit',
            method: 'POST'
          },
          cancel: {
            label: 'Cancel',
            action: 'reset'
          }
        } : undefined,
        styling: {
          theme: 'light',
          layout: fields.length > 6 ? 'two-column' : 'single-column'
        }
      };
      
      const processingTime = Date.now() - startTime;
      const confidence = Math.min(0.95, 0.7 + (fieldKeywords.length * 0.05));
      
      return {
        success: true,
        structure,
        confidence,
        processingTime,
        suggestions: this.generateSuggestions(description, fieldKeywords)
      };
      
    } catch (error) {
      return {
        success: false,
        confidence: 0,
        processingTime: Date.now() - startTime,
        error: error instanceof Error ? error.message : 'Unknown error occurred'
      };
    }
  }
  
  private generateSuggestions(description: string, extractedFields: string[]): string[] {
    const suggestions: string[] = [];
    
    if (extractedFields.length < 3) {
      suggestions.push('Consider adding more field details for better structure generation');
    }
    
    if (!description.toLowerCase().includes('required') && !description.toLowerCase().includes('optional')) {
      suggestions.push('Specify which fields are required vs optional');
    }
    
    if (!description.toLowerCase().includes('validation')) {
      suggestions.push('Add validation requirements for better form structure');
    }
    
    return suggestions;
  }
}

export const mlService = new MLService();