import React from 'react';
import { Eye, Layout } from 'lucide-react';
import { JSONPageStructure, JSONField } from '../types';

interface PreviewPanelProps {
  structure: JSONPageStructure | null;
}

const PreviewPanel: React.FC<PreviewPanelProps> = ({ structure }) => {
  const renderField = (field: JSONField) => {
    const baseClasses = "w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent";
    
    switch (field.type) {
      case 'textarea':
        return (
          <textarea
            key={field.id}
            placeholder={field.placeholder}
            required={field.required}
            className={`${baseClasses} resize-none h-24`}
            readOnly
          />
        );
      
      case 'select':
        return (
          <select key={field.id} required={field.required} className={baseClasses} disabled>
            <option value="">{field.placeholder}</option>
            {field.options?.map((option, idx) => (
              <option key={idx} value={option}>{option}</option>
            ))}
          </select>
        );
      
      case 'radio':
        return (
          <div key={field.id} className="space-y-2">
            {field.options?.map((option, idx) => (
              <label key={idx} className="flex items-center space-x-2">
                <input
                  type="radio"
                  name={field.id}
                  value={option}
                  className="text-blue-600"
                  disabled
                />
                <span className="text-sm text-gray-700">{option}</span>
              </label>
            ))}
          </div>
        );
      
      case 'checkbox':
        return (
          <label key={field.id} className="flex items-center space-x-2">
            <input
              type="checkbox"
              required={field.required}
              className="text-blue-600"
              disabled
            />
            <span className="text-sm text-gray-700">{field.label}</span>
          </label>
        );
      
      default:
        return (
          <input
            key={field.id}
            type={field.type}
            placeholder={field.placeholder}
            required={field.required}
            className={baseClasses}
            readOnly
          />
        );
    }
  };

  if (!structure) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Eye className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">Preview Unavailable</h3>
          <p className="text-gray-500">Generate a structure to see the live preview</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-center space-x-2 mb-6">
        <Layout className="w-5 h-5 text-green-600" />
        <h2 className="text-lg font-semibold text-gray-900">Live Preview</h2>
      </div>

      <div className="max-h-96 overflow-y-auto">
        <div className="bg-gray-50 p-6 rounded-lg">
          <div className="bg-white p-6 rounded-lg shadow-sm max-w-2xl mx-auto">
            <div className="mb-6">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">{structure.title}</h1>
              {structure.description && (
                <p className="text-gray-600">{structure.description}</p>
              )}
            </div>

            <form className="space-y-6">
              {structure.sections.map((section) => (
                <div key={section.id} className="space-y-4">
                  <div className="border-b border-gray-200 pb-2">
                    <h2 className="text-lg font-semibold text-gray-800">{section.title}</h2>
                    {section.description && (
                      <p className="text-sm text-gray-600 mt-1">{section.description}</p>
                    )}
                  </div>
                  
                  <div className={`grid gap-4 ${
                    structure.styling?.layout === 'two-column' ? 'grid-cols-2' : 'grid-cols-1'
                  }`}>
                    {section.fields.map((field) => (
                      <div key={field.id} className="space-y-2">
                        {field.type !== 'checkbox' && (
                          <label className="block text-sm font-medium text-gray-700">
                            {field.label}
                            {field.required && <span className="text-red-500 ml-1">*</span>}
                          </label>
                        )}
                        {renderField(field)}
                        {field.description && (
                          <p className="text-xs text-gray-500">{field.description}</p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ))}

              {structure.actions && (
                <div className="flex items-center justify-between pt-6 border-t border-gray-200">
                  {structure.actions.cancel && (
                    <button
                      type="button"
                      className="px-4 py-2 text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300 transition-colors duration-200"
                      disabled
                    >
                      {structure.actions.cancel.label}
                    </button>
                  )}
                  {structure.actions.submit && (
                    <button
                      type="submit"
                      className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 ml-auto"
                      disabled
                    >
                      {structure.actions.submit.label}
                    </button>
                  )}
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PreviewPanel;