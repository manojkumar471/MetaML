import React, { useState } from 'react';
import { Send, Loader2, Lightbulb, Wand2 } from 'lucide-react';

interface InputPanelProps {
  onGenerate: (description: string) => void;
  isLoading: boolean;
}

const InputPanel: React.FC<InputPanelProps> = ({ onGenerate, isLoading }) => {
  const [description, setDescription] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (description.trim() && !isLoading) {
      onGenerate(description.trim());
    }
  };

  const examplePrompts = [
    "A registration form with name, email, phone number, and password fields",
    "Contact form with name, email, subject, message, and file attachment",
    "User profile form with personal information, address, and preferences",
    "Survey form with multiple choice questions and rating scales",
    "Job application form with personal details, experience, and skills"
  ];

  const useExample = (example: string) => {
    setDescription(example);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-center space-x-2 mb-4">
        <Wand2 className="w-5 h-5 text-blue-600" />
        <h2 className="text-lg font-semibold text-gray-900">Natural Language Input</h2>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
            Describe your page structure
          </label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe the form or page you want to create... e.g., 'A registration form with name, email, phone number fields and a submit button'"
            className="w-full h-32 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
            disabled={isLoading}
          />
        </div>
        
        <button
          type="submit"
          disabled={!description.trim() || isLoading}
          className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Generating Structure...</span>
            </>
          ) : (
            <>
              <Send className="w-4 h-4" />
              <span>Generate JSON Structure</span>
            </>
          )}
        </button>
      </form>
      
      <div className="mt-6 pt-6 border-t border-gray-200">
        <div className="flex items-center space-x-2 mb-3">
          <Lightbulb className="w-4 h-4 text-yellow-500" />
          <h3 className="text-sm font-medium text-gray-700">Example Prompts</h3>
        </div>
        <div className="grid gap-2">
          {examplePrompts.map((example, index) => (
            <button
              key={index}
              onClick={() => useExample(example)}
              className="text-left p-3 text-sm text-gray-600 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200"
              disabled={isLoading}
            >
              {example}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default InputPanel;