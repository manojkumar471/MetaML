import React from 'react';
import { Brain, Zap } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-white border-b border-gray-200 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="flex items-center justify-center w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">MetaML</h1>
            <p className="text-sm text-gray-500">Intelligent JSON Page Structure Generator</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
            <Zap className="w-4 h-4" />
            <span>Model Ready</span>
          </div>
          <div className="text-sm text-gray-600">
            <span className="font-medium">v1.0.0</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;