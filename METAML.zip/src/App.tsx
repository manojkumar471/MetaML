import React, { useState } from 'react';
import Header from './components/Header';
import InputPanel from './components/InputPanel';
import OutputPanel from './components/OutputPanel';
import PreviewPanel from './components/PreviewPanel';
import StatsPanel from './components/StatsPanel';
import { mlService } from './services/mlService';
import { GenerationResult } from './types';

function App() {
  const [result, setResult] = useState<GenerationResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerate = async (description: string) => {
    setIsLoading(true);
    try {
      const generationResult = await mlService.generateStructure(description);
      setResult(generationResult);
    } catch (error) {
      setResult({
        success: false,
        confidence: 0,
        processingTime: 0,
        error: 'An unexpected error occurred while generating the structure.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      
      <div className="max-w-7xl mx-auto px-6 py-6">
        <div className="grid grid-cols-12 gap-6">
          {/* Left Column - Input */}
          <div className="col-span-12 lg:col-span-4 space-y-6">
            <InputPanel onGenerate={handleGenerate} isLoading={isLoading} />
            <StatsPanel />
          </div>
          
          {/* Middle Column - Output */}
          <div className="col-span-12 lg:col-span-4">
            <OutputPanel result={result} />
          </div>
          
          {/* Right Column - Preview */}
          <div className="col-span-12 lg:col-span-4">
            <PreviewPanel structure={result?.structure || null} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;